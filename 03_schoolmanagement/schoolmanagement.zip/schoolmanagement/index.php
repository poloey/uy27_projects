<?php 
header('location:pages/login.php');

?>