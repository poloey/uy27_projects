	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2017 CMS </b> All rights reserved.
		</div>
	</div>